const http = require("http");

const port = process.env.PORT || 3000;

http
  .createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("This app should not start because the build fails first.\n");
  })
  .listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
